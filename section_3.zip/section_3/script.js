"use strict";

let hasDriversLicense = false;
const passTest = true;

if (passTest) hasDriversLicense = true;
if (hasDriversLicense) console.log("I can drive :D");

// const interface = 'Audio';
// const private = 534;

function logger() {
  console.log("My name is Mukhamedzhan");
}

// calling / running / invoking function
logger();
