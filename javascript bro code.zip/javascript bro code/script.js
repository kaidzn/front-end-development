// let adult = checkAge(12 );
// console.log(adult);

// function checkAge(age) {
//   return age >= 18 ? true : false;
// }
////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////

// the difference between var and let...

// let = variables are limited to block scope{}
// var = variables are limited to a function(){}

// global variable = is declared outside any function
// (if global, var will CHANGE browser's window properties)

// let name = "Bro";

// doSomething();
// function doSomething() {
//   for (let /*var*/ i = 1; i <= 3; i++) {
//     //console.log(i);
//   }
// }
// console.log(i);
///////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////

// Templates literals = delimited with (`)
//          instead of double or single quotes
//          allows embedded variables and expressions
